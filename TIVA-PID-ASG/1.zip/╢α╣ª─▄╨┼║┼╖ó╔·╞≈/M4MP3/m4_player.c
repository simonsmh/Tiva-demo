#include <stdint.h>
#include <stdbool.h>

void player()
{
    
}
